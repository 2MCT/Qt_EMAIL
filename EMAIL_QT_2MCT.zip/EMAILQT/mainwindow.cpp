#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "SmtpMime"
#include <QMessageBox>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    MimeMessage message;
    SmtpClient smtp("smtp.gmail.com", 465, SmtpClient::SslConnection);
    smtp.setPassword("wkmz rttd zwat lwac ");

    smtp.setUser("nrandriamiarimanana@gmail.com");
    smtp.setPassword("wkmz rttd zwat lwac "); // Utilisez le mot de passe spécifique à l'application

    message.setSender(new EmailAddress("nrandriamiarimanana@gmail.com", "Nomenjanahary Randriamiarimanana"));
    message.addRecipient(new EmailAddress("andoravaly@gmail.com", "Ando Ravaly"));
    message.setSubject("Isaorana ANDRIAMANITRA");

    MimeText text;
    text.setText("Dera sy Laza ho Azy irery\n");
    message.addPart(&text);

    if (!smtp.connectToHost()) {
        QMessageBox::critical(this, "Erreur de connexion", "Échec de la connexion au serveur SMTP.");
        return;
    }

    if (!smtp.login()) {
        QMessageBox::critical(this, "Erreur d'authentification", "Échec de l'authentification.");
        smtp.quit();
        return;
    }

    if (smtp.sendMail(message)) {
        QMessageBox::information(this, "Succès", "Message envoyé avec succès !");
    } else {
        QMessageBox::critical(this, "Erreur d'envoi", "Échec de l'envoi du message.");
    }

    smtp.quit();
}

// smtpclient.cpp

#include "smtpclient.h"
#include <QFileInfo>
#include <QByteArray>
#include <QSslSocket>
#include <QDebug>

// Constructeur
SmtpClient::SmtpClient(const QString &host, int port, ConnectionType ct) :
    socket(nullptr),
    host(host),
    port(port),
    connectionType(ct),
    name("localhost"),
    authMethod(AuthPlain),
    connectionTimeout(5000),
    responseTimeout(5000),
    sendMessageTimeout(60000)
{
    setConnectionType(ct);
}

// Destructeur
SmtpClient::~SmtpClient() {
    if (socket) {
        socket->disconnectFromHost();
        socket->waitForDisconnected();
        delete socket;
    }
}

// Getters et Setters
const QString& SmtpClient::getHost() const {
    return host;
}

void SmtpClient::setHost(const QString &host) {
    this->host = host;
}

int SmtpClient::getPort() const {
    return port;
}

void SmtpClient::setPort(int port) {
    this->port = port;
}

const QString& SmtpClient::getName() const {
    return name;
}

void SmtpClient::setName(const QString &name) {
    this->name = name;
}

SmtpClient::ConnectionType SmtpClient::getConnectionType() const {
    return connectionType;
}

void SmtpClient::setConnectionType(ConnectionType ct) {
    this->connectionType = ct;

    if (socket) {
        socket->disconnectFromHost();
        delete socket;
    }

    switch (connectionType) {
    case TcpConnection:
        socket = new QTcpSocket(this);
        break;
    case SslConnection:
    case TlsConnection:
        socket = new QSslSocket(this);
        break;
    }

    // Connecter les signaux du socket aux slots appropriés
    connect(socket, &QAbstractSocket::stateChanged, this, &SmtpClient::socketStateChanged);
    connect(socket, &QAbstractSocket::errorOccurred, this, &SmtpClient::socketError);
    connect(socket, &QIODevice::readyRead, this, &SmtpClient::socketReadyRead);
}

const QString& SmtpClient::getUser() const {
    return user;
}

void SmtpClient::setUser(const QString &user) {
    this->user = user;
}

const QString& SmtpClient::getPassword() const {
    return password;
}

void SmtpClient::setPassword(const QString &password) {
    this->password = password;
}

SmtpClient::AuthMethod SmtpClient::getAuthMethod() const {
    return authMethod;
}

void SmtpClient::setAuthMethod(AuthMethod method) {
    this->authMethod = method;
}

const QString& SmtpClient::getResponseText() const {
    return responseText;
}

int SmtpClient::getResponseCode() const {
    return responseCode;
}

int SmtpClient::getConnectionTimeout() const {
    return connectionTimeout;
}

void SmtpClient::setConnectionTimeout(int msec) {
    connectionTimeout = msec;
}

int SmtpClient::getResponseTimeout() const {
    return responseTimeout;
}

void SmtpClient::setResponseTimeout(int msec) {
    responseTimeout = msec;
}

int SmtpClient::getSendMessageTimeout() const {
    return sendMessageTimeout;
}

void SmtpClient::setSendMessageTimeout(int msec) {
    sendMessageTimeout = msec;
}

QTcpSocket* SmtpClient::getSocket() {
    return socket;
}

// Méthodes publiques
bool SmtpClient::connectToHost() {
    if (!socket) {
        qDebug() << "Socket not initialized!";
        return false;
    }

    switch (connectionType) {
    case TlsConnection:
    case TcpConnection:
        socket->connectToHost(host, port);
        if (!socket->waitForConnected(connectionTimeout)) {
            emit smtpError(ConnectionTimeoutError);
            return false;
        }
        break;
    case SslConnection:
        ((QSslSocket*)socket)->connectToHostEncrypted(host, port);
        if (!socket->waitForConnected(connectionTimeout)) {
            emit smtpError(ConnectionTimeoutError);
            return false;
        }
        if (!((QSslSocket*)socket)->waitForEncrypted(connectionTimeout)) {
            emit smtpError(ConnectionTimeoutError);
            return false;
        }
        break;
    }

    // Assurer que le socket est connecté
    if (socket->state() != QAbstractSocket::ConnectedState) {
        qDebug() << "Socket not connected!";
        return false;
    }

    // Connecter les signaux après avoir confirmé l'état du socket
    connect(socket, &QAbstractSocket::connected, this, &SmtpClient::onConnected);
    connect(socket, &QAbstractSocket::disconnected, this, &SmtpClient::onDisconnected);
    connect(socket, &QAbstractSocket::errorOccurred, this, &SmtpClient::onSocketError);

    return true;
}

bool SmtpClient::sendEHLO() {
    try {
        sendMessage("EHLO " + name); // Send EHLO command
        waitForResponse(); // Wait for the server's response

        // Check if the response code indicates success (250)
        return responseCode == 250;
    }
    catch (const ResponseTimeoutException&) {
        emit smtpError(ResponseTimeoutError);
        return false;
    }
    catch (const SendMessageTimeoutException&) {
        emit smtpError(SendDataTimeoutError);
        return false;
    }
}


bool SmtpClient::login() {
    if (!sendEHLO()) {
        return false;
    }

    try {
        QByteArray credentials;
        credentials.append((char)0).append(user).append((char)0).append(password);
        sendMessage("AUTH PLAIN " + credentials.toBase64());
        waitForResponse(); // Wait for AUTH response

        return responseCode == 235; // 235 indicates successful authentication
    }
    catch (const ResponseTimeoutException&) {
        emit smtpError(ResponseTimeoutError);
        return false;
    }
    catch (const SendMessageTimeoutException&) {
        emit smtpError(SendDataTimeoutError);
        return false;
    }
}


bool SmtpClient::login(const QString &user, const QString &password, AuthMethod method) {
    try {
        if (method == AuthPlain) {
            QByteArray credentials;
            credentials.append((char)0).append(user).append((char)0).append(password);
            sendMessage("AUTH PLAIN " + credentials.toBase64());
            waitForResponse();
        } else if (method == AuthLogin) {
            sendMessage("AUTH LOGIN");
            waitForResponse(); // Attente de 334

            sendMessage(QByteArray().append(user).toBase64());
            waitForResponse(); // Attente de 334

            sendMessage(QByteArray().append(password).toBase64());
            waitForResponse(); // Attente de 235
        }

        return responseCode == 235;
    }
    catch (const ResponseTimeoutException&) {
        emit smtpError(ResponseTimeoutError);
        return false;
    }
    catch (const SendMessageTimeoutException&) {
        emit smtpError(SendDataTimeoutError);
        return false;
    }
}

bool SmtpClient::sendMail(MimeMessage& email) {
    try {
        sendMessage("MAIL FROM: <" + email.getSender().getAddress() + ">");
        waitForResponse(); // Attente de 250

        for (const auto& recipient : email.getRecipients()) {
            sendMessage("RCPT TO: <" + recipient->getAddress() + ">");
            waitForResponse(); // Attente de 250
        }

        for (const auto& recipient : email.getRecipients(MimeMessage::Cc)) {
            sendMessage("RCPT TO: <" + recipient->getAddress() + ">");
            waitForResponse(); // Attente de 250
        }

        for (const auto& recipient : email.getRecipients(MimeMessage::Bcc)) {
            sendMessage("RCPT TO: <" + recipient->getAddress() + ">");
            waitForResponse(); // Attente de 250
        }

        sendMessage("DATA");
        waitForResponse(); // Attente de 354

        sendMessage(email.toString());
        sendMessage(".");

        waitForResponse(); // Attente de 250

        return responseCode == 250;
    }
    catch (const ResponseTimeoutException&) {
        emit smtpError(ResponseTimeoutError);
        return false;
    }
    catch (const SendMessageTimeoutException&) {
        emit smtpError(SendDataTimeoutError);
        return false;
    }
}

void SmtpClient::quit() {
    try {
        sendMessage("QUIT");
    }
    catch (const SendMessageTimeoutException&) {
        if (socket && (socket->state() == QAbstractSocket::ConnectedState ||
                       socket->state() == QAbstractSocket::ConnectingState ||
                       socket->state() == QAbstractSocket::HostLookupState)) {
            socket->disconnectFromHost();
        }
    }
}


void SmtpClient::socketStateChanged(QAbstractSocket::SocketState state) {
    qDebug() << "Socket state changed:" << state;
}

void SmtpClient::onConnected() {
    qDebug() << "Connected to server";

    // Send EHLO command
    sendMessage("EHLO " + name);
    waitForResponse(); // Wait for EHLO response

    // Proceed with authentication
    if (!login()) {
        qDebug() << "Authentication failed";
        return;
    }

    // Send other commands (e.g., MAIL FROM, RCPT TO, DATA) here
}



void SmtpClient::onDisconnected() {
    qDebug() << "Socket disconnected";
    // Traitement supplémentaire pour la déconnexion si nécessaire
}

void SmtpClient::onSocketError(QAbstractSocket::SocketError socketError) {
    qDebug() << "Socket error:" << socketError;
    if (socketError == QAbstractSocket::RemoteHostClosedError) {
        qDebug() << "Remote host closed the connection.";
    }
    emit smtpError(ServerError);
}

void SmtpClient::socketError(QAbstractSocket::SocketError socketError) {
    qDebug() << "Socket error:" << socketError;
    emit smtpError(ServerError);
}

void SmtpClient::socketReadyRead() {
    while (socket->canReadLine()) {
        responseText = socket->readLine().trimmed();
        qDebug() << "Received response:" << responseText;
        responseCode = responseText.left(3).toInt();

        // Handle different response codes
        if (responseCode / 100 == 4) {
            qDebug() << "Server returned a 4xx response code:" << responseText;
            emit smtpError(ServerError);
        }
        else if (responseCode / 100 == 5) {
            qDebug() << "Server returned a 5xx response code:" << responseText;
            emit smtpError(ClientError);
        }

        // Exit when response is complete
        if (responseText[3] == ' ') {
            return;
        }
    }
}


/*=============================*/

void SmtpClient::sendMessage(const QString &text) {
    if (!socket) {
        qDebug() << "Socket not initialized!";
        return;
    }

    if (socket->state() != QAbstractSocket::ConnectedState) {
        qDebug() << "Socket not connected!";
        emit smtpError(ServerError);
        return;
    }

    qDebug() << "Sending command:" << text;
    socket->write(text.toUtf8() + "\r\n");
    if (!socket->waitForBytesWritten(sendMessageTimeout)) {
        qDebug() << "Send data timeout";
        emit smtpError(SendDataTimeoutError);
        throw SendMessageTimeoutException();
    }
}

void SmtpClient::waitForResponse() {
    if (!socket) return;

    if (!socket->waitForReadyRead(responseTimeout)) {
        qDebug() << "Response timeout";
        emit smtpError(ReceiveDataTimeoutError);
        throw ResponseTimeoutException();
    }

    while (socket->canReadLine()) {
        responseText = socket->readLine().trimmed();
        qDebug() << "Received response:" << responseText;
        responseCode = responseText.left(3).toInt();
        if (responseCode / 100 == 4) {
            qDebug() << "Server returned a 4xx response code:" << responseText;
            emit smtpError(ServerError);
        }
        else if (responseCode / 100 == 5) {
            qDebug() << "Server returned a 5xx response code:" << responseText;
            emit smtpError(ClientError);
        }
        if (responseText[3] == ' ') {
            return;
        }
    }
}
